import re, requests, collections, pandas


def extractFromRegularExpresion(regex, data):
    if data:
        return re.findall(regex, data)
    return None

dataD=""
with open(r"http\access_log", "rt") as f:
    dataD=f.read()
regex = r"^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}).*?\b[A-Z]{3,7}\b\s(\/\S+).*?(\d{3})"

resultado = extractFromRegularExpresion(regex, dataD)

for item in resultado:
    print(resultado)